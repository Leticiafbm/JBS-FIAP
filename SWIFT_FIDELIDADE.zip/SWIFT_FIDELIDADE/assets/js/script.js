const progressBar = document.getElementById("progressBar");
const progressText = document.getElementById("progressText");
const buttons = document.querySelectorAll(".resgatar");
const purchaseTask = document.getElementById("purchaseTask");

const levels = [100, 150, 200, 300]; 
let currentPoints = 0;
let purchaseDone = false;

updateProgress();

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    const pts = parseInt(btn.getAttribute("data-points"));
    if (currentPoints >= pts) {
      spendPoints(pts);
      alert("Resgate realizado com sucesso!");
    } else {
      alert("Você não tem pontos suficientes para resgatar!");
    }
    updateProgress();
  });
});

purchaseTask.addEventListener("click", () => {
  if (!purchaseDone) {
    gainPoints(20);
    purchaseTask.classList.add("completed");
    purchaseDone = true;
    updateProgress();
  }
});

function spendPoints(points) {
  if (currentPoints >= points) {
    currentPoints -= points;
    updateProgress();
  }
}

function gainPoints(points) {
  currentPoints += points;
  updateProgress();
}

function updateProgress() {
  let nextLevel = levels.find(level => currentPoints < level) || levels[levels.length - 1];
  let prevLevel = 0;
  for (let i = 0; i < levels.length; i++) {
    if (currentPoints < levels[i]) {
      prevLevel = i > 0 ? levels[i-1] : 0;
      nextLevel = levels[i];
      break;
    }
  }
  let percentage = ((currentPoints - prevLevel) / (nextLevel - prevLevel)) * 100;
  progressBar.style.width = Math.min(percentage, 100) + "%";
  progressText.textContent = `Você possui ${currentPoints} pontos (próximo objetivo: ${nextLevel} Pts)`;

  buttons.forEach(btn => {
    const pts = parseInt(btn.getAttribute("data-points"));
    btn.disabled = currentPoints < pts;
    btn.classList.toggle("disabled", currentPoints < pts);
  });
}
